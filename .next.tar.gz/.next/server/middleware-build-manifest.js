globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/5BgoHfqutgy1X-d_3f0I-/_buildManifest.js",
    "static/5BgoHfqutgy1X-d_3f0I-/_ssgManifest.js",
    "static/5BgoHfqutgy1X-d_3f0I-/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0x1uqee_e0c0r.js",
    "static/chunks/0152g1m.qoqad.js",
    "static/chunks/0i7m2nhk_g00n.js",
    "static/chunks/0vc4yp~ia1cm9.js",
    "static/chunks/turbopack-133.q6q9vlq28.js"
  ]
};
