1:"$Sreact.fragment"
2:"$Sreact.suspense"
3:I[74654,["/_next/static/chunks/0bkyw01wauwm7.js","/_next/static/chunks/026b8z4oasaq3.js","/_next/static/chunks/0yq441j~ssj3c.js","/_next/static/chunks/030aww7~0hjop.js"],"AppShell"]
4:I[32664,["/_next/static/chunks/0bkyw01wauwm7.js"],"OutletBoundary"]
0:{"rsc":["$","$1","c",{"children":[["$","$2",null,{"children":["$","$L3",null,{}]}],[["$","script","script-0",{"src":"/_next/static/chunks/026b8z4oasaq3.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/0yq441j~ssj3c.js","async":true}],["$","script","script-2",{"src":"/_next/static/chunks/030aww7~0hjop.js","async":true}]],["$","$L4",null,{"children":["$","$2",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"5BgoHfqutgy1X-d_3f0I-"}
5:null
