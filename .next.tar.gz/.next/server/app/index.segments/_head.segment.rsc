1:"$Sreact.fragment"
2:I[32664,["/_next/static/chunks/0bkyw01wauwm7.js"],"ViewportBoundary"]
3:I[32664,["/_next/static/chunks/0bkyw01wauwm7.js"],"MetadataBoundary"]
4:"$Sreact.suspense"
5:I[755,["/_next/static/chunks/0bkyw01wauwm7.js"],"IconMark"]
0:{"rsc":["$","$1","h",{"children":[null,["$","$L2",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","div",null,{"hidden":true,"children":["$","$L3",null,{"children":["$","$4",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Pi Agent Web"}],["$","meta","1",{"name":"description","content":"Pi Coding Agent Web Interface"}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.0~uco8ba8mwit.ico","sizes":"512x512","type":"image/x-icon"}],["$","$L5","3",{}]]}]}]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"5BgoHfqutgy1X-d_3f0I-"}
