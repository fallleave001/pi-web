:HL["/_next/static/chunks/0g8l.dnr4f7_-.css","style"]
:HL["/_next/static/media/7da1b2d9318915d2-s.p.0jn-y.~othqka.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/bfe1d01af4e99ec2-s.p.0xkmhr9m~odtp.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"5BgoHfqutgy1X-d_3f0I-"}
