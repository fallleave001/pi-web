1:"$Sreact.fragment"
2:I[32568,["/_next/static/chunks/0bkyw01wauwm7.js"],"default"]
3:I[93707,["/_next/static/chunks/0bkyw01wauwm7.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"5BgoHfqutgy1X-d_3f0I-"}
