var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0.m~pv6._.js")
R.c("server/chunks/11xr_next_dist_esm_build_templates_app-route_0.--fsn.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0amv_PI-web_pi-web-pr__next-internal_server_app_favicon_ico_route_actions_0xs_4c~.js")
R.m(65372)
module.exports=R.m(65372).exports
