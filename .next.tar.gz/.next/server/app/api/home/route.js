var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/home/route.js")
R.c("server/chunks/[root-of-the-server]__0a7a7rd._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0amv_PI-web_pi-web-pr__next-internal_server_app_api_home_route_actions_0gityh3.js")
R.m(71283)
module.exports=R.m(71283).exports
