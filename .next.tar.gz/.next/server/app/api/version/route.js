var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/version/route.js")
R.c("server/chunks/[root-of-the-server]__0vf-x7c._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0amv_PI-web_pi-web-pr__next-internal_server_app_api_version_route_actions_0qa4~dc.js")
R.m(77504)
module.exports=R.m(77504).exports
