var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/models-config/test/route.js")
R.c("server/chunks/[root-of-the-server]__0r0j2wc._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/016___next-internal_server_app_api_models-config_test_route_actions_07011ip.js")
R.m(81105)
module.exports=R.m(81105).exports
