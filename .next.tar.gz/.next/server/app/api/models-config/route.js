var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/models-config/route.js")
R.c("server/chunks/[root-of-the-server]__0ke-5ez._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0r6r_pi-web-pr__next-internal_server_app_api_models-config_route_actions_10jr4ds.js")
R.m(1236)
module.exports=R.m(1236).exports
