var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/skills/search/route.js")
R.c("server/chunks/[root-of-the-server]__0adj777._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0r6r_pi-web-pr__next-internal_server_app_api_skills_search_route_actions_0s-fzoh.js")
R.m(31477)
module.exports=R.m(31477).exports
