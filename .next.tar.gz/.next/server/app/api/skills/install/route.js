var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/skills/install/route.js")
R.c("server/chunks/[root-of-the-server]__0w898i.._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0r6r_pi-web-pr__next-internal_server_app_api_skills_install_route_actions_06ap_bf.js")
R.m(74539)
module.exports=R.m(74539).exports
