var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/skills/route.js")
R.c("server/chunks/[root-of-the-server]__0dcgyb_._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0amv_PI-web_pi-web-pr__next-internal_server_app_api_skills_route_actions_0vr.pqy.js")
R.m(46989)
module.exports=R.m(46989).exports
