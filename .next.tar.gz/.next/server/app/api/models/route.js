var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/models/route.js")
R.c("server/chunks/[root-of-the-server]__0qq39ly._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/0amv_PI-web_pi-web-pr__next-internal_server_app_api_models_route_actions_0m82c0-.js")
R.m(20653)
module.exports=R.m(20653).exports
