var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/[provider]/route.js")
R.c("server/chunks/[root-of-the-server]__0gw_y~6._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/016___next-internal_server_app_api_auth_login_[provider]_route_actions_0r~w2gb.js")
R.m(3351)
module.exports=R.m(3351).exports
