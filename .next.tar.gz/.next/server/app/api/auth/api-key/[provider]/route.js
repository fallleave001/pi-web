var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/api-key/[provider]/route.js")
R.c("server/chunks/[root-of-the-server]__01359cj._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/016___next-internal_server_app_api_auth_api-key_[provider]_route_actions_0tp~nf2.js")
R.m(93713)
module.exports=R.m(93713).exports
