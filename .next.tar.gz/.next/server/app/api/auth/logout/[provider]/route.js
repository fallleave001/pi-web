var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/[provider]/route.js")
R.c("server/chunks/[root-of-the-server]__04ivl36._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/016___next-internal_server_app_api_auth_logout_[provider]_route_actions_0kche-_.js")
R.m(41376)
module.exports=R.m(41376).exports
