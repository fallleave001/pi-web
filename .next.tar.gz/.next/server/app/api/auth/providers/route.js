var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/providers/route.js")
R.c("server/chunks/[root-of-the-server]__0-zlw.-._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/0r6r_pi-web-pr__next-internal_server_app_api_auth_providers_route_actions_0alv2fi.js")
R.m(22422)
module.exports=R.m(22422).exports
