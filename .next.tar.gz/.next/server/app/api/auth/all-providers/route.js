var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/all-providers/route.js")
R.c("server/chunks/[root-of-the-server]__0jjs2k1._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/016___next-internal_server_app_api_auth_all-providers_route_actions_13tlx08.js")
R.m(81931)
module.exports=R.m(81931).exports
