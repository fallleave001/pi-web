var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/files/[...path]/route.js")
R.c("server/chunks/[root-of-the-server]__0d72_nx._.js")
R.c("server/chunks/Desktop_PI-web_pi-web-pr_0hp_4_-._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0r6r_pi-web-pr__next-internal_server_app_api_files_[___path]_route_actions_0.dpnkk.js")
R.m(50026)
module.exports=R.m(50026).exports
