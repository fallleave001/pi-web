var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/tools/route.js")
R.c("server/chunks/[root-of-the-server]__08vj_g~._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0amv_PI-web_pi-web-pr__next-internal_server_app_api_tools_route_actions_10vlrrj.js")
R.m(67007)
module.exports=R.m(67007).exports
