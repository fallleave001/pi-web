var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/agent/[id]/events/route.js")
R.c("server/chunks/[root-of-the-server]__10-x9ql._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/0r6r_pi-web-pr__next-internal_server_app_api_agent_[id]_events_route_actions_0o9.7.1.js")
R.m(50789)
module.exports=R.m(50789).exports
