var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/agent/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0ycmrt6._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0amv_PI-web_pi-web-pr__next-internal_server_app_api_agent_[id]_route_actions_0.ks893.js")
R.m(62640)
module.exports=R.m(62640).exports
