var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/agent/new/route.js")
R.c("server/chunks/[root-of-the-server]__0mj4pz4._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0amv_PI-web_pi-web-pr__next-internal_server_app_api_agent_new_route_actions_0o59vq3.js")
R.m(93934)
module.exports=R.m(93934).exports
