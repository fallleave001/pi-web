var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sessions/[id]/context/route.js")
R.c("server/chunks/[root-of-the-server]__00z-5pk._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/016___next-internal_server_app_api_sessions_[id]_context_route_actions_0hkulek.js")
R.m(75730)
module.exports=R.m(75730).exports
