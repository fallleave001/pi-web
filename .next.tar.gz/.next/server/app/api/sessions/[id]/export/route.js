var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/sessions/[id]/export/route.js")
R.c("server/chunks/[root-of-the-server]__0p~k7nh._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/016___next-internal_server_app_api_sessions_[id]_export_route_actions_0968rty.js")
R.m(80043)
module.exports=R.m(80043).exports
