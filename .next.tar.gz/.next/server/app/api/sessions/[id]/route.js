var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/sessions/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0th.y_n._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0r6r_pi-web-pr__next-internal_server_app_api_sessions_[id]_route_actions_0k2v09r.js")
R.m(35872)
module.exports=R.m(35872).exports
