var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sessions/route.js")
R.c("server/chunks/[root-of-the-server]__0h236r-._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0amv_PI-web_pi-web-pr__next-internal_server_app_api_sessions_route_actions_0pbeyb5.js")
R.m(37181)
module.exports=R.m(37181).exports
