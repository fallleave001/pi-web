var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/sessions/new/route.js")
R.c("server/chunks/[root-of-the-server]__02kb1ia._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/0r6r_pi-web-pr__next-internal_server_app_api_sessions_new_route_actions_0kg0rhv.js")
R.m(17374)
module.exports=R.m(17374).exports
