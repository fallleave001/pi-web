var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/default-cwd/route.js")
R.c("server/chunks/[root-of-the-server]__0h87j76._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0r6r_pi-web-pr__next-internal_server_app_api_default-cwd_route_actions_00jbhn-.js")
R.m(11645)
module.exports=R.m(11645).exports
