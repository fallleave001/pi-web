var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cwd/validate/route.js")
R.c("server/chunks/[root-of-the-server]__02bpd18._.js")
R.c("server/chunks/[root-of-the-server]__0m-s8vf._.js")
R.c("server/chunks/11xr_next_0ohr6n~._.js")
R.c("server/chunks/0r6r_pi-web-pr__next-internal_server_app_api_cwd_validate_route_actions_071xxfq.js")
R.m(34775)
module.exports=R.m(34775).exports
