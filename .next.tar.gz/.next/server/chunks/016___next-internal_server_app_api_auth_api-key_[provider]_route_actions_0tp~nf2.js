module.exports=[16354,(e,o,d)=>{}];

//# sourceMappingURL=016___next-internal_server_app_api_auth_api-key_%5Bprovider%5D_route_actions_0tp~nf2.js.map