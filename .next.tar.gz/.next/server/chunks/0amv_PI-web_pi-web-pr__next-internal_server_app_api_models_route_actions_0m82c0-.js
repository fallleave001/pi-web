module.exports=[87934,(e,o,d)=>{}];

//# sourceMappingURL=0amv_PI-web_pi-web-pr__next-internal_server_app_api_models_route_actions_0m82c0-.js.map