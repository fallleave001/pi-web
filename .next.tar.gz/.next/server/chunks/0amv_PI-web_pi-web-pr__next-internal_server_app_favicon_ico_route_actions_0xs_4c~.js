module.exports=[20003,(e,o,d)=>{}];

//# sourceMappingURL=0amv_PI-web_pi-web-pr__next-internal_server_app_favicon_ico_route_actions_0xs_4c~.js.map