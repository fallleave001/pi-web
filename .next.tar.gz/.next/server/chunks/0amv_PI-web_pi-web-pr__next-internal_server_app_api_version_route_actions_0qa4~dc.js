module.exports=[71108,(e,o,d)=>{}];

//# sourceMappingURL=0amv_PI-web_pi-web-pr__next-internal_server_app_api_version_route_actions_0qa4~dc.js.map