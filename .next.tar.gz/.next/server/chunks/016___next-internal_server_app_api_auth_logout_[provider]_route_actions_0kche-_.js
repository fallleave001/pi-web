module.exports=[6484,(e,o,d)=>{}];

//# sourceMappingURL=016___next-internal_server_app_api_auth_logout_%5Bprovider%5D_route_actions_0kche-_.js.map