module.exports=[42187,(e,o,d)=>{}];

//# sourceMappingURL=0amv_PI-web_pi-web-pr__next-internal_server_app_api_skills_route_actions_0vr.pqy.js.map