module.exports=[31625,(e,o,d)=>{}];

//# sourceMappingURL=0amv_PI-web_pi-web-pr__next-internal_server_app_api_agent_new_route_actions_0o59vq3.js.map