module.exports=[10351,(a,b,c)=>{}];

//# sourceMappingURL=0amv_PI-web_pi-web-pr__next-internal_server_app__global-error_page_actions_00ndzj5.js.map