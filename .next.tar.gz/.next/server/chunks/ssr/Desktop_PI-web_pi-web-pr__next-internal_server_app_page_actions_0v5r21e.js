module.exports=[50084,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_PI-web_pi-web-pr__next-internal_server_app_page_actions_0v5r21e.js.map