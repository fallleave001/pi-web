module.exports=[11983,(a,b,c)=>{}];

//# sourceMappingURL=0amv_PI-web_pi-web-pr__next-internal_server_app__not-found_page_actions_0.7y6-2.js.map