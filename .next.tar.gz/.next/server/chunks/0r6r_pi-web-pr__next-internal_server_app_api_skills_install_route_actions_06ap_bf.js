module.exports=[67755,(e,o,d)=>{}];

//# sourceMappingURL=0r6r_pi-web-pr__next-internal_server_app_api_skills_install_route_actions_06ap_bf.js.map