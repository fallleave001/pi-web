module.exports=[1125,(e,o,d)=>{}];

//# sourceMappingURL=0r6r_pi-web-pr__next-internal_server_app_api_skills_search_route_actions_0s-fzoh.js.map