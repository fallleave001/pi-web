(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,86673,e=>{"use strict";var t=(0,e.i(7117).__name)(()=>`
  /* Font Awesome icon styling - consolidated */
  .label-icon {
    display: inline-block;
    height: 1em;
    overflow: visible;
    vertical-align: -0.125em;
  }
  
  .node .label-icon path {
    fill: currentColor;
    stroke: revert;
    stroke-width: revert;
  }
`,"getIconStyles");e.s(["getIconStyles",0,t])},59651,e=>{"use strict";var t=e.i(50528),l=e.i(10194);e.s(["channel",0,(e,o)=>t.default.lang.round(l.default.parse(e)[o])],59651)}]);